# MiniCluster — Tonight's 1-Hour Runbook (skeleton build)

## 0. Upload + unpack (2 min)
Upload minicluster_pkg.tar.gz to /workspace/shared via Jupyter file browser, then:

    cd /workspace/shared
    tar xzf minicluster_pkg.tar.gz        # creates/updates minicluster/
    cd minicluster

## 1. Dependencies (1 min — fastapi/uvicorn/httpx likely present already)

    pip install fastapi uvicorn httpx psutil redis

## 2. Generate config for THIS box (dynamic core split)

    python3 gen_conf.py
    # expect: 112 cores | node-1: 0-55 | node-2: 56-111

## 3. Launch the cluster

    supervisord -c supervisord.conf
    sleep 3
    supervisorctl -c supervisord.conf status
    # expect 7 RUNNING: redis, payments, auth, checkout, fraud, loadgen, collector

## 4. Prove it's alive (the skeleton checkpoints)

    curl -s http://127.0.0.1:7001/health
    curl -s http://127.0.0.1:7001/work
    sleep 45 && tail -5 live_metrics.csv      # rows flowing, rps > 0

## 5. Prove fault -> visible in metrics (mini demo)

    curl -s -X POST "http://127.0.0.1:7001/fault/latency?ms=600"
    sleep 60 && tail -5 live_metrics.csv      # payments latency_p95_ms jumps
    curl -s -X POST "http://127.0.0.1:7001/fault/clear"

## 6. Prove remediation (the money primitive)

    supervisorctl -c supervisord.conf restart payments
    supervisorctl -c supervisord.conf status   # fresh pid, RUNNING
    sleep 60 && tail -5 live_metrics.csv       # metrics recover

## 7. Shut down cleanly (or leave running if continuing)

    supervisorctl -c supervisord.conf shutdown

## 8. MANDATORY end-of-session tar

    cd /workspace
    tar czf shared_backup_$(date +%Y%m%d).tar.gz shared/ --exclude=shared/myenv
    ls -lh shared_backup_*.tar.gz
    # download via Jupyter file browser

## Notes
- All processes are supervised; nothing survives `shutdown`. Logs in minicluster/logs/.
- live_metrics.csv uses SIM-MINUTE stamping (1 row-set per 15s real, stamped +1 min)
  and the pipeline's column shape: timestamp, service, cpu_utilization, rps,
  latency_p95_ms, error_rate (+ mem_mb, node).
- Saturday adds: pgserver + pool_leak (UC-2), tracing middleware, chaos scheduler,
  detection wiring (point the replay-loop consumer at live_metrics.csv — same adapter).
- If a service shows BACKOFF/FATAL: cat logs/<name>.err
